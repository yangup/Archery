version = (1, 9, 1)
display_version = ".".join(str(i) for i in version)
