# -*- coding: UTF-8 -*-


# 在这里写配置可以覆盖 archery/settings.py 内的配置
# DATABASES = {}
